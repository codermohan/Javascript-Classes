async function executePromise() {
    let test = new Promise(function (resolve, reject) {
        setTimeout(function () {
            reject("rejected after 3 seconds");
        }, 3000);
    })
    test.then(function (a) {
        console.log(a);
    }).catch(function (error) {
        console.log(error);
    })
    try {
        console.log('using try block');
        const data = await test;
        JSON.parse("{\"name\":\"sumanth\"}");
        console.log("promise Resolved and parse is successed");
    }
    catch (error) {
        console.log("using catch block");
        const data=await test;
        console.log(error);
    }
}
executePromise();