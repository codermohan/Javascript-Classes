/*function getRequest() {
    let xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function () {
        console.log("Before getting request");
        if (this.readyState === 4 && this.status === 200)
            console.log("After getting request");
    }
    xmlHttp.open('GET', 'https://jsonplaceholder.typicode.com/comments', false);
    xmlHttp.send();
    console.log('End of the request');
}
getRequest();*/

 function fetchData() {
     fetch('https://jsonplaceholder.typicode.com/comments/?postId=50&id=250', {
        method: 'GET',
        headers: {
            "Content-Type": "application/json"
        }
    }).then(async res => {
        console.log(res.status);
        const data = await res.json();
        console.log(data);
    }).catch(error => {
        console.log(error);
    })
    console.log("I'm out of fetch");
}
fetchData();