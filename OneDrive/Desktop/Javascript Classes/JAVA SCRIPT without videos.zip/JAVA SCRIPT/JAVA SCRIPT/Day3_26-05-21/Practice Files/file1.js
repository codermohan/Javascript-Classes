function abc(a)
{
    console.log(a,'file1 is called');
}