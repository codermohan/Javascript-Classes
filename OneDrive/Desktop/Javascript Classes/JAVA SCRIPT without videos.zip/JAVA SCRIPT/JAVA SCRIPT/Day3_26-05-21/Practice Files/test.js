function abc()
{
    console.log('In external test js File');
    const paraElement = document.createElement('p');
    console.log(paraElement);
    paraElement.innerHTML = 'paragraph';
}

abc();