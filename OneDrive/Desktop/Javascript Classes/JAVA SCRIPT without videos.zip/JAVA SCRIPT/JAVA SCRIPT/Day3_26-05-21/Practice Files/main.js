function abc()
{
    console.log('In external main js File');
    const headingTag = document.getElementById('heading');
    const classTag = document.getElementsByClassName('color');
    const nameTag = document.getElementsByName('name');

    console.log(headingTag);
    console.log(classTag);
    console.log(nameTag);
}

abc();
