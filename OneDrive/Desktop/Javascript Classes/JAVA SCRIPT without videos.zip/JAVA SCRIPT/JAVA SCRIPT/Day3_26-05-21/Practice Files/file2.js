function abc(a)
{
    console.log(a,'file2 is called');
}