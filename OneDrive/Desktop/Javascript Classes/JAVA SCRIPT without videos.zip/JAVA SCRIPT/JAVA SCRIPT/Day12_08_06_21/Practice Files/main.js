function* genFunc() {
    console.log("In Generator function 1");
    console.log("In Generator function 2");

    yield 10;
    console.log("In yield 1");
    console.log("In Generator function 3");

    yield 20;
    console.log("In yield 2");
    console.log("In Generator function 4");
}
const a = genFunc();
console.log(a.next());
console.log(a.throw());