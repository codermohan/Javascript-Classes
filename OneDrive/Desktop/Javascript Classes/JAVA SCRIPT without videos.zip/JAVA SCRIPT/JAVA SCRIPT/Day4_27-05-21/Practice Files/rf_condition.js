function generateHTML() {
    const divContainer = document.createElement('div');
    const heading = document.createElement('h1');
    heading.innerHTML = 'Creating Registration Form Though JAVA SCRIPT';

    const para = document.createElement('p');
    para.innerHTML = 'Enter your details';

    const form = document.createElement('form');
    var obj = [{ element: 'input', type: 'text', placeholder: 'Enter Username', name: 'username', id: 'username', event: false },
    { element: 'input', type: 'password', placeholder: 'Enter Password', name: 'password', id: 'password', event: false },
    { element: 'button', type: 'button', name: 'button', id: 'button', event: true, eventType: 'click' }];
    
    const breakTag = document.createElement('br');

    for (let i = 0; i < obj.length; i++) {
        if (obj[i].event === true) {
            const Submit = document.createElement(obj[i].element);
            Submit.setAttribute('type', obj[i].type);
            Submit.innerHTML = "SUBMIT";
            Submit.addEventListener(obj[i].eventType, function () {
                const nameValue = document.getElementById(obj[i - 2].id).value;
                const password = document.getElementById(obj[i - 1].id).value;
                console.log('username: ', nameValue);
                console.log('password: ', password);
            })
            form.appendChild(Submit);
        }
        else {
            const abc = document.createElement(obj[i].element);
            abc.setAttribute('placeholder', obj[i].placeholder);
            abc.setAttribute('id', obj[i].id);
            abc.setAttribute('type', obj[i].type);
            abc.setAttribute('class', 'margin-15');
            form.appendChild(abc);
            form.appendChild(breakTag);
            form.appendChild(breakTag);
        }
    }

    divContainer.appendChild(heading);
    divContainer.appendChild(para);
    divContainer.appendChild(form);

    document.body.appendChild(divContainer);
}

generateHTML();