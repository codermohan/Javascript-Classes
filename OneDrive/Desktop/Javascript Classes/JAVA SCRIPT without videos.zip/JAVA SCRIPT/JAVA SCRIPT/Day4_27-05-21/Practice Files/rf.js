function generateHTML()
{
    const divContainer = document.createElement('div');

    const heading = document.createElement('h1');
    heading.innerHTML = 'Creating Registration Form Though JAVA SCRIPT';

    const para = document.createElement('p');
    para.innerHTML = 'Enter your details';

    const form =  document.createElement('form');
    
    const Name = document.createElement('input');
    Name.setAttribute('placeholder','Enter your name');
    Name.setAttribute('id','name');
    Name.setAttribute('type','text');

    const Email = document.createElement('input');
    Email.setAttribute('placeholder','Enter your mail');
    Email.setAttribute('id','email');
    Email.setAttribute('type','email');
    Email.setAttribute('class','margin-15');

    const Number = document.createElement('input');
    Number.setAttribute('placeholder','Enter your mobile number');
    Number.setAttribute('id','number');
    Number.setAttribute('type','number');
    Number.setAttribute('class','margin-15');

    const Agree = document.createElement('input');
    Agree.setAttribute('type','checkbox');
    Agree.setAttribute('id','agree');
    Agree.setAttribute('class','margin-15');

    const a=document.createElement('p');
    a.innerHTML = 'Agree the Terms & Conditions';
   
    const Submit = document.createElement('button');
    Submit.setAttribute('type','button');
    Submit.innerHTML = 'SUBMIT';
    Submit.addEventListener('click',function() {
        const nameValue = document.getElementById('name').value;
        const emailValue = document.getElementById('email').value;
        const numberValue = document.getElementById('number').value;
        console.log('Name   :',nameValue);
        console.log('Email  :',emailValue);
        console.log('Number :',numberValue);
    })

    const breakTag = document.createElement('br');

    form.appendChild(Name);
    form.appendChild(breakTag);
    form.appendChild(breakTag);
    form.appendChild(Email);
    form.appendChild(breakTag);
    form.appendChild(breakTag);
    form.appendChild(Number);
    form.appendChild(breakTag);
    form.appendChild(breakTag);
    form.appendChild(a);
    form.appendChild(Agree);
    form.appendChild(breakTag);
    form.appendChild(breakTag);
    form.appendChild(Submit);

    divContainer.appendChild(heading);
    divContainer.appendChild(para);
    divContainer.appendChild(form);

    document.body.appendChild(divContainer);
}

generateHTML();