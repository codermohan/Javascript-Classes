var obj = {
    a: 20,
    details: null
}
console.log(obj && obj.details && obj.details.age);
console.log(obj?.details?.age);