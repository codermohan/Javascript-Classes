'use strict';
add();
var x=10;
function add(){
    console.log(this.x);
}
