function generateHTML() {
    const divContainer = document.createElement('div');

    const heading = document.createElement('h1');
    heading.innerHTML = 'ADD DATA TO THE TABLE';

    const para = document.createElement('p');
    para.innerHTML = 'Enter your details';

    const form = document.createElement('form');
    form.setAttribute('id', 'form');

    const Name = document.createElement('input');
    Name.setAttribute('placeholder', 'Enter your name');
    Name.setAttribute('id', 'name');
    Name.setAttribute('type', 'text');

    const Number = document.createElement('input');
    Number.setAttribute('placeholder', 'Enter your number');
    Number.setAttribute('id', 'number');
    Number.setAttribute('type', 'number');
    Number.setAttribute('class', 'margin-15');


    const table1 = document.createElement('table');
    table1.setAttribute('id', 'table1');
    table1.innerHTML="<tr><td>"+"USERNAME"+"</td><td>"+"MOBILE"+"</td></tr>";

    const addToTable = document.createElement('button');
    addToTable.setAttribute('type', 'button');
    addToTable.innerHTML = 'ADD';
    addToTable.addEventListener('click', function () {
        const nameValue = document.getElementById('name').value;
        const numberValue = document.getElementById('number').value;
        const rows = document.getElementById("table1");
        rows.innerHTML += "<tr><td>" + nameValue + "</td><td>" + numberValue + "</td></tr>";
    })

    const resetData = document.createElement('button');
    resetData.setAttribute('type', 'button');
    resetData.innerHTML = 'RESET';
    resetData.addEventListener('click', function () {
        document.getElementById('form').reset();
    })

    const breakTag = document.createElement('br');

    form.appendChild(Name);
    form.appendChild(breakTag);
    form.appendChild(breakTag);
    form.appendChild(Number);
    form.appendChild(breakTag);
    form.appendChild(breakTag);
    form.appendChild(breakTag);
    form.appendChild(breakTag);
    form.appendChild(addToTable);
    form.appendChild(resetData);
    form.appendChild(breakTag);
    form.appendChild(breakTag);
    form.appendChild(table1);
   

    divContainer.appendChild(heading);
    divContainer.appendChild(para);
    divContainer.appendChild(form);

    document.body.appendChild(divContainer);
}

generateHTML();