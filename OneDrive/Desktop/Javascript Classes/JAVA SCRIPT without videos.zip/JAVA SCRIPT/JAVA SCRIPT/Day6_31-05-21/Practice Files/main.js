const arr = [{ name: "defined", email: "defined@gmail.com", mobile: 1234 }];
var i = 0;
function setStorage() {
    var a = 0;
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var mobile = document.getElementById('mobile').value;

    for (i = 0; i < arr.length; i++) {
        if (arr[i].email === email)
            a = 1;
    }
    if (a === 1)
        alert('Email already exists')
    else if (a === 0) {
        arr.push({ name: name, email: email, mobile: mobile });
        localStorage.setItem('Array of Objects', JSON.stringify(arr));
        alert('Successfully dumped to local storage');
    }
}
function getStorage() {
    const value=JSON.parse(localStorage.getItem('Array of Objects'));
    for (i = 1; i < value.length; i++) {
        document.write("<b>" + "<center>" + "User" + i + " Details" + "</center>" + "</b>" + "<br>");
        document.write("Username  : " + value[i].name + "<br>");
        document.write("Email ID  : " + value[i].email + "<br>");
        document.write("Mobile Number: " + value[i].mobile + "<br><br>");
    }
}