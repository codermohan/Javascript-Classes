function request(successRespCb, errorRespCb, methodName, URL) {
    let xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            let arr = this.response;
            createTable(arr);
            successRespCb(arr);
        }
        else {
            errorRespCb(this.status);
        }
    }
    xmlHttp.open(methodName, URL);
    xmlHttp.send();

}

request(successResp, errorResp, 'GET', 'https://jsonplaceholder.typicode.com/todos');

function successResp(object) {
    console.log(object);
}

function errorResp(error) {
    console.log(error);
}

function createTable(arr) {
    const divContainer = document.createElement("div");
    const heading = document.createElement("h1");
    heading.innerHTML = "XML HTTP REQUEST AND PRINTING OBJ IN TABLE";

    const Table = document.createElement("table");
    Table.setAttribute("class", 'tr1');

    const Tr = document.createElement('tr');
    const Td1_head = document.createElement("td");
    Td1_head.innerHTML = "userId";
    const Td2_head = document.createElement("td");
    Td2_head.innerHTML = "id";
    const Td3_head = document.createElement("td");
    Td3_head.innerHTML = "title";
    const Td4_head = document.createElement("td");
    Td4_head.innerHTML = "completed";

    Table.appendChild(Tr);
    Tr.appendChild(Td1_head);
    Tr.appendChild(Td2_head);
    Tr.appendChild(Td3_head);
    Tr.appendChild(Td4_head);

    var a = JSON.parse(arr);
    for (let i = 0; i < a.length; i++) {
        const Tr1 = document.createElement("tr");
        const Td1_data = document.createElement('td');
        Td1_data.innerHTML = a[i].userId;
        const Td2_data = document.createElement('td');
        Td2_data.innerHTML = a[i].id;
        const Td3_data = document.createElement('td');
        Td3_data.innerHTML = a[i].title;
        const Td4_data = document.createElement('td');
        Td4_data.innerHTML = a[i].completed;

        Table.appendChild(Tr1);
        Tr1.appendChild(Td1_data);
        Tr1.appendChild(Td2_data);
        Tr1.appendChild(Td3_data);
        Tr1.appendChild(Td4_data);
    }

    divContainer.appendChild(heading);
    divContainer.appendChild(Table);

    document.body.append(divContainer);

}
