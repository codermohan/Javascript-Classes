function request(successRespCb, errorRespCb, methodName, URL) {
    let xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            let arr = this.response;
            console.log(this.getAllResponseHeaders);
            successRespCb(arr);
        }
        else {
            errorRespCb(this.status);
        }
    }
    xmlHttp.open(methodName, URL);
    xmlHttp.setRequestHeader('Content-Type','application/json');
    xmlHttp.send();

}

request(successResp, errorResp, 'GET', 'https://jsonplaceholder.typicode.com/todos');

function successResp(response) {
    console.log(response);
}

function errorResp(error) {
    console.log(error);
}