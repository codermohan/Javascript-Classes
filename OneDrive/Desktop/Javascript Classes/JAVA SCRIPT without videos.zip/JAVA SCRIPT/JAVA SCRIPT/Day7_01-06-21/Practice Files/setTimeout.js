console.log("before setTimeout")
for (var i = 0; i < 5; i++) {
    setTimeout(function () {
        console.log("using var", i);
    }, 2000)
}
for (let i = 0; i < 5; i++) {
    setTimeout(function () {
        console.log("using let", i);
    }, 3000)
}
console.log("after setTimeout");