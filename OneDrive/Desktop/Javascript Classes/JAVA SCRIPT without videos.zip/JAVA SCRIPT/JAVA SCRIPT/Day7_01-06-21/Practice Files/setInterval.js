console.log("before setInterval")
setInterval(function(){
    console.log("using setInterval")
},3000);
console.log("after setInterval")