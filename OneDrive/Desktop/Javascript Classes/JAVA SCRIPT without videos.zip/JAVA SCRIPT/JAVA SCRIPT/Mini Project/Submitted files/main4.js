var arr = JSON.parse(localStorage.getItem('Users Data'));
var data = JSON.parse(localStorage.getItem('Logged In User'));
if (arr == null) { window.alert("Users doesnt exist, Click OK to Registration"); location.href = "register.html"; }
else if (data == null) { window.alert("You are not logged in, Click OK to login"); location.href = "login.html"; }
else {
    for (let i = 1; i < arr.length; i++) {
        var table = document.getElementById('users_data');
        var table_len = (table.rows.length);
        var row = table.insertRow(table_len).outerHTML = "<tr><td>" + arr[i].name + "</td><td>" + arr[i].email + "</td><td>" + arr[i].mobile +
         "</td><td>" + arr[i].gender + "</td><td><input type='button' class='main' value='EDIT' onclick='edit_row(" + table_len + ")'><input type='button' class='main' value='DELETE' class='delete' onclick='delete_row(" + table_len + ")'></td></tr>";
    }
}

function edit_row(value) {
    var a = arr[value];
    if (window.confirm("You want to edit " + a.name + " details") == true) {
        localStorage.setItem("Edit User Details", JSON.stringify(a));
        location.href = "edit_users_profile.html"
    }
    else return;
}

function delete_row(value) {
    if (data.email == arr[value].email)
        window.alert("You Cannot Delete Your Account Right Now");
    else {
        if (window.confirm("You want to delete " + arr[value].name + " details") == true) {
            arr.splice(value, 1);
            localStorage.setItem('Users Data', JSON.stringify(arr));
            location.href = "list.html";
        }
        else return;
    }
}

function func() {
    location.href = "dashboard.html"
}