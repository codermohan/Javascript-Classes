var data = JSON.parse(localStorage.getItem('Logged In User'));
var arr = JSON.parse(localStorage.getItem('Users Data'));

if (data == null || arr == null) {
    if (window.alert("Data Doesn't exists Click Ok to Login Page") == true)
        location.href = "login.html"
}
else {

    document.getElementById('name').value = data.name;
    document.getElementById('email').value = data.email;
    document.getElementById('mobile').value = data.mobile;
    document.getElementById('gender').value = data.gender;
    document.getElementById('password').value = data.password;
}

function submit() {
    var a = {}, b = 0;
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const mobile = document.getElementById('mobile').value;
    const gender = document.getElementById('gender').value;
    const password = document.getElementById('password').value;

    if (name != data.name) alert("User Name Modified");
    if (email != data.email) alert("User Email Modified");
    if (mobile != data.mobile) alert("User Mobile Modified");
    if (gender != data.gender) alert("User Gender Modified");
    if (password != data.password) alert("User Password Modified");

    a = { name: name, email: email, mobile: mobile, gender: gender, password: password };
    for (let i = 1; i < arr.length; i++) {
        if (data.email == arr[i].email) {
            arr[i] = a;
            data = a;
            b = i;
        }
    }

    if (b != 0)
        if (window.confirm("User Details Edited,  Click Ok to Save") == true) {
            localStorage.setItem("Users Data", JSON.stringify(arr));
            localStorage.setItem("Logged In User", JSON.stringify(data));
            window.alert("User Data Saved Successfully");
            location.href = "profile.html"
        }
        else {
            window.alert("User Data not Saved");
            location.href = "profile.html";
        }

}