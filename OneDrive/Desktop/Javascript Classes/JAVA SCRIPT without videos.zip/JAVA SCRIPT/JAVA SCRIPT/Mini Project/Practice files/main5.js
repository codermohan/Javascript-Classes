var data1 = JSON.parse(localStorage.getItem('Edit User Details'));
var data2 = JSON.parse(localStorage.getItem("Logged In User"))
var arr = JSON.parse(localStorage.getItem('Users Data'));

if (data2 == null || arr == null) {
    if (window.alert("Data Doesn't exists Click Ok to Login Page") == true)
        location.href = "login.html"
}
else {

    document.getElementById('name').value = data1.name;
    document.getElementById('email').value = data1.email;
    document.getElementById('mobile').value = data1.mobile;
    document.getElementById('gender').value = data1.gender;
    document.getElementById('password').value = data1.password;
}

function submit() {
    var a = {}, b = 0;
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const mobile = document.getElementById('mobile').value;
    const gender = document.getElementById('gender').value;
    const password = document.getElementById('password').value;

    if (name != data1.name) alert("User Name Modified");
    if (email != data1.email) alert("User Email Modified");
    if (mobile != data1.mobile) alert("User Mobile Modified");
    if (gender != data1.gender) alert("User Gender Modified");
    if (password != data1.password) alert("User Password Modified");

    a = { name: name, email: email, mobile: mobile, gender: gender, password: password };
    for (let i = 1; i < arr.length; i++) {
        if (data1.email == arr[i].email) {
            arr[i] = a;
            b = i;
        }
    }

    if (b != 0)
        if (window.confirm("User Details Edited,  Click Ok to Save") == true) {
            localStorage.setItem("Users Data", JSON.stringify(arr));
            if (data2.email == data1.email)
                localStorage.setItem("Logged In User", JSON.stringify(a));
            window.alert("User Data Saved Successfully");
            localStorage.removeItem("Edit User Details");
            location.href = "list.html"
        }
        else {
            window.alert("User Data not Saved");
            location.href = "list.html";
        }

}