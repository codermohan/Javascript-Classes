function reset_pass() {
    const old_pass = document.getElementById('old_pass').value;
    const new_pass = document.getElementById('new_pass').value;
    const conf_pass = document.getElementById('conf_pass').value;

    if (old_pass == "") window.alert("Please Enter Old Password");
    else if (new_pass == "") window.alert("Please Enter New Password");
    else if (conf_pass == "") window.alert("Please Enter Confirm Password");
    else if (new_pass !== conf_pass) window.alert("New and Confirm password are not matched Please Try again");
    else if (validate(old_pass, new_pass, conf_pass)) {
        window.alert('Password Resetted Successfully');
        location.href = "dashboard.html";
    }
    else alert("Old Password is not matching Please Try Again");
}
function validate(...args) {
    var arr = JSON.parse(localStorage.getItem('Users Data'));
    var data = JSON.parse(localStorage.getItem('Logged In User'));
    var a = 0;
    for (let i = 0; i < arr.length; i++) {
        if (data.email == arr[i].email) {
            if (arr[i].password == args[0]) {
                arr[i].password = args[1];
                data.password = args[1];
                a = i;
            }
            else return false
        }
    }
    localStorage.setItem('Users Data', JSON.stringify(arr));
    localStorage.setItem('Logged In User', JSON.stringify(data));
    if (a != 0)
        return true;
}

function func() {
    location.href="dashboard.html";
}