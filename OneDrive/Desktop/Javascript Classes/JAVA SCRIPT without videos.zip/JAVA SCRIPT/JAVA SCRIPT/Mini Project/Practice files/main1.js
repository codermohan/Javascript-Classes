var arr, i = 0;
const data = JSON.parse(localStorage.getItem('Users Data'));
if (data == null) arr = [{}];
else arr = data;


function Register() {
    var a = 0;
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var mobile = document.getElementById('mobile').value;
    var gender = document.getElementById('gender').value;
    var password = document.getElementById('password').value;

    store(name, email, mobile, gender, password);
}
function store(name, email, mobile, gender, password) {
    var a = 0;
    if (validate(name, email, mobile, gender, password)) {
        for (i = 1; i < arr.length; i++) {
            if (arr[i].name === name) a = 1;
            if (arr[i].mobile === mobile) a = 2;
            if (arr[i].email === email) a = 3;
        }
        if (a == 1)
            window.alert('Name Already Exists');
        else if (a == 2)
            window.alert('Mobile Number Already Exists');
        else if (a == 3)
            window.alert('Email Already Exixts');
        else if (a === 0) {

            arr.push({ name: name, email: email, mobile: mobile, gender: gender, password: password });
            localStorage.setItem('Users Data', JSON.stringify(arr));
            alert('Your Details Registered Successfully');
        }
    }
}

function validate(name, email, mobile, gender, password) {
    if (name == "") window.alert("Please enter the name");
    else if (email == "") window.alert("Please enter the valid email");
    else if (mobile < 1111111111) window.alert("Please enter the valid mobile");
    else if (gender == "Select") window.alert("Please select the gender");
    else if (password == "") window.alert("Please enter the password and password must be <6");
    else if (document.form1.button1.checked == false) window.alert("Please Agree the terms And Conditions");
    else return true;
}

function func() {
    location.href = "login.html";
}